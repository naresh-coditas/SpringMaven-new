package com.test.cache.impl;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.coditas.cache.InMemoryCacheDemoApplication;
import com.coditas.cache.impl.CacheManager;
import com.coditas.cache.service.CacheTestService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = InMemoryCacheDemoApplication.class)
public class CacheAnnotationsTest {

	@Autowired
	CacheTestService cacheTestService;

	@Autowired
	CacheManager cacheManager;
	
	@Before
	public void init() {
		cacheManager.flushCache();
	}

	@Test
	@DirtiesContext
	public void testCachableAnnotation() {
		cacheTestService.initDataStore("Default Value");
		String result = cacheTestService.getRecord();
		assertEquals("Default Value", cacheManager.get("key_1"));
		assertEquals("Default Value", result);
	}
	
	@Test
	public void testCacheSetAnnotation() {
		String result = cacheTestService.saveRecord("New Value");
		assertEquals("New Value", result);
		assertEquals("New Value", cacheTestService.getRecord());
		assertEquals("New Value", cacheManager.get("key_1"));
	}
	
	@Test
	public void testCacheRemoveAnnotation() {
		cacheTestService.saveRecord("New Value");
		cacheTestService.removeRecord();
		assertEquals(null, cacheTestService.getRecord());
		assertEquals(null, cacheManager.get("key_1"));
	}
}