package com.coditas.cache.impl;

import java.lang.reflect.Method;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.AnnotationUtils;

import com.coditas.cache.annotation.CacheRemove;
import com.coditas.cache.annotation.CacheSet;
import com.coditas.cache.annotation.Cacheable;

@Aspect
@Configuration
public class CachableAnnotationImpl {

	@Autowired
	private CacheManager cacheManager;

	@Around("@annotation(com.coditas.cache.annotation.Cacheable)")
	public Object aroundCacheableMethod(ProceedingJoinPoint pjp) throws Throwable {
		MethodSignature signature = (MethodSignature) pjp.getSignature();
		Method method = signature.getMethod();
		Cacheable annotation = AnnotationUtils.findAnnotation(method, Cacheable.class);
		String objectKey = annotation.key();
		Object result = cacheManager.get(objectKey);
		if (result == null) {
			result = pjp.proceed();
			cacheManager.set(objectKey, result);
		}
		return result;
	}

	@Around("@annotation(com.coditas.cache.annotation.CacheSet)")
	public Object aroundCacheSetMethod(ProceedingJoinPoint pjp) throws Throwable {
		MethodSignature signature = (MethodSignature) pjp.getSignature();
		Method method = signature.getMethod();
		CacheSet annotation = AnnotationUtils.findAnnotation(method, CacheSet.class);
		String objectKey = annotation.key();
		Object cachedObject = cacheManager.get(objectKey);
		Object result = pjp.proceed();
		if(cachedObject != null)
		{
			cacheManager.set(objectKey, result);
		}
		return result;
	}
	
	@Around("@annotation(com.coditas.cache.annotation.CacheRemove)")
	public Object aroundCacheRemovetMethod(ProceedingJoinPoint pjp) throws Throwable {
		MethodSignature signature = (MethodSignature) pjp.getSignature();
		Method method = signature.getMethod();
		CacheRemove annotation = AnnotationUtils.findAnnotation(method, CacheRemove.class);
		String objectKey = annotation.key();
		cacheManager.remove(objectKey);
		return pjp.proceed();
	}
}
