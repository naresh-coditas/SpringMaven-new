package com.coditas.cache.service;

import org.springframework.stereotype.Component;

import com.coditas.cache.annotation.CacheRemove;
import com.coditas.cache.annotation.CacheSet;
import com.coditas.cache.annotation.Cacheable;

@Component
public class CacheTestService {

	private String dataStore = "Default Value";
	@Cacheable(key = "key_1")
	public String getRecord() {
		return dataStore;
	}
	
	@CacheSet(key = "key_1")
	public String saveRecord(String value) {
		dataStore = value;
		return dataStore;
	}
	
	@CacheRemove(key = "key_1")
	public String removeRecord() {
		dataStore = null;
		return dataStore;
	}

	public void initDataStore(String value) {
		dataStore = value;
	}
}
