package com.coditas.cache.impl;

class CacheNode {
	private String key;
	private Object value;
	private CacheNode pre;
	private CacheNode next;

	public CacheNode(String paramKey, Object paramValue) {
		this.key = paramKey;
		this.value = paramValue;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String paramKey) {
		this.key = paramKey;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public CacheNode getPre() {
		return pre;
	}

	public void setPre(CacheNode pre) {
		this.pre = pre;
	}

	public CacheNode getNext() {
		return next;
	}

	public void setNext(CacheNode next) {
		this.next = next;
	}
}
