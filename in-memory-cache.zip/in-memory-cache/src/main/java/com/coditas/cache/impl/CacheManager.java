package com.coditas.cache.impl;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CacheManager {
	private HashMap<String, CacheNode> map;
	private int count;

	private CacheNode head;
	
	private CacheNode tail;

	private Integer capicity;

	public int getCount() {
		return count;
	}
	
	public Integer getCapicity() {
		return capicity;
	}

	public CacheManager(@Value("${cache.capicity}") Integer capacity) {
		this.capicity = capacity;
		map = new HashMap<String, CacheNode>();
		head = new CacheNode("0", 0);
		tail = new CacheNode("0", 0);
		head.setNext(tail);
		tail.setPre(head);
		head.setPre(null);
		tail.setNext(null);
		count = 0;
	}

	private void deleteCacheNode(CacheNode cacheNode) {
		cacheNode.getPre().setNext(cacheNode.getNext());
		cacheNode.getNext().setPre(cacheNode.getPre());
	}

	private void addToHead(CacheNode cacheNode) {
		cacheNode.setNext(head.getNext());
		cacheNode.getNext().setPre(cacheNode);
		cacheNode.setPre(head);
		head.setNext(cacheNode);
	}

	public Object remove(String key) {
		if (map.get(key) != null) {
			CacheNode cacheNode = map.get(key);
			Object result = cacheNode.getValue();
			deleteCacheNode(cacheNode);
			map.remove(key);
			return result;
		}
		return null;
	}

	public Object get(String key) {
		if (map.get(key) != null) {
			CacheNode cacheNode = map.get(key);
			Object result = cacheNode.getValue();
			deleteCacheNode(cacheNode);
			addToHead(cacheNode);
			return result;
		}
		return null;
	}

	public void set(String key, Object value) {
		if (map.get(key) != null) {
			CacheNode cacheNode = map.get(key);
			cacheNode.setValue(value);
			deleteCacheNode(cacheNode);
			addToHead(cacheNode);
		} else {
			CacheNode cacheNode = new CacheNode(key, value);
			map.put(key, cacheNode);
			if (count < capicity) {
				count++;
				addToHead(cacheNode);
			} else {
				map.remove(tail.getPre().getKey());
				deleteCacheNode(tail.getPre());
				addToHead(cacheNode);
			}
		}
	}

	public void flushCache() {
		map.clear();
		head = new CacheNode("0", 0);
		tail = new CacheNode("0", 0);
		head.setNext(tail);
		tail.setPre(head);
		head.setPre(null);
		tail.setNext(null);
		count = 0;
	}
}
